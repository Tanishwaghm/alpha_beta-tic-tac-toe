
# 🤖 AI Spy: Guess the Secret Code

A fun logic deduction game where an AI uses Minimax with Alpha-Beta pruning to guess your secret 4-digit code.

## 🎮 How to Play
1. You enter a 4-digit code with no repeating digits.
2. The AI will try to guess the code within 10 tries.
3. After each guess, the AI receives feedback:
   - 🟩 Correct digit & position
   - 🟨 Correct digit but wrong position

## 🧠 AI Logic
The AI builds a game tree and uses Minimax + Alpha-Beta pruning to choose the most optimal guesses, reducing the search space efficiently.

## 📦 Files
- `ai_spy_guess.py`: The main game file.
- `README.md`: Project description.

## 🚀 Run the Game
```bash
python ai_spy_guess.py
```
