
import itertools
import random

ALL_CODES = ["".join(p) for p in itertools.permutations("0123456789", 4)]

def get_feedback(secret, guess):
    green = sum(s == g for s, g in zip(secret, guess))
    yellow = sum(min(secret.count(d), guess.count(d)) for d in set(guess)) - green
    return green, yellow

def minimax(possible_codes, all_codes, depth, alpha, beta, maximizing):
    if depth == 0 or len(possible_codes) == 1:
        return len(possible_codes), None

    best_guess = None
    if maximizing:
        max_eval = float('-inf')
        for guess in all_codes:
            partitions = {}
            for code in possible_codes:
                feedback = get_feedback(code, guess)
                partitions.setdefault(feedback, []).append(code)
            worst_case = max(len(group) for group in partitions.values())
            if worst_case < max_eval:
                continue
            eval, _ = minimax(possible_codes, all_codes, depth - 1, alpha, beta, False)
            if eval > max_eval:
                max_eval = eval
                best_guess = guess
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval, best_guess
    else:
        min_eval = float('inf')
        for guess in all_codes:
            partitions = {}
            for code in possible_codes:
                feedback = get_feedback(code, guess)
                partitions.setdefault(feedback, []).append(code)
            worst_case = max(len(group) for group in partitions.values())
            if worst_case > min_eval:
                continue
            eval, _ = minimax(possible_codes, all_codes, depth - 1, alpha, beta, True)
            if eval < min_eval:
                min_eval = eval
                best_guess = guess
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval, best_guess

def ai_spy_game():
    print("🤫 Welcome to AI Spy: Guess the Secret Code!")
    secret = input("Enter a secret 4-digit code (no repeats, hidden from AI): ")
    while not (len(secret) == 4 and secret.isdigit() and len(set(secret)) == 4):
        secret = input("Invalid. Try again: ")

    possible_codes = ALL_CODES.copy()
    attempts = 0

    while attempts < 10:
        print(f"\n🔍 Attempt {attempts+1}:")
        _, guess = minimax(possible_codes, ALL_CODES, 1, float('-inf'), float('inf'), True)
        if not guess:
            guess = random.choice(possible_codes)
        print(f"AI guesses: {guess}")
        feedback = get_feedback(secret, guess)
        print(f"🟩 Correct Pos: {feedback[0]}, 🟨 Wrong Pos: {feedback[1]}")

        if feedback[0] == 4:
            print(f"\n🎉 AI cracked the code in {attempts+1} attempts!")
            break

        possible_codes = [code for code in possible_codes if get_feedback(code, guess) == feedback]
        attempts += 1
    else:
        print(f"\n❌ AI failed to guess your code. Secret was: {secret}")

if __name__ == "__main__":
    ai_spy_game()
